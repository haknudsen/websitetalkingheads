<?php
 $referersite = strtolower($_SERVER['HTTP_REFERER']);

$name= $_REQUEST['name'];
$email = $_REQUEST['email'];
$phone = $_REQUEST['phone'];
$company = $_REQUEST['company'];
$message = $_REQUEST['theMessage'];
$sentIP = $_REQUEST['sentIP'];

$verified = true;

foreach ($_REQUEST as $key => $value)  {
		 	 $hrefFinder = strripos($value, "href");
		 	 $urlFinder = strripos($value, "url=");
			 echo $key." - ".$value." - ".$hrefFinder." - ".$urlFinder."</br>";
		 if(is_numeric($hrefFinder) or is_numeric($urlFinder)){
			 echo "fail</br>";
			 $verified = false;
         }else{
			 echo "pass</br>";
		 }
}


if( !preg_match("/^([1]-)?[0-9]{3}-[0-9]{3}-[0-9]{4}$/i", $phone) ) { 
	if($phone == "" || $phone == "XXX-XXX-XXXX" || $phone == "Phone"){
	}else{
	$verified = false;
	}
}	
if ($phone == "123456"){
	$verified = false;
	}
if ($company == "google"){
	$verified = false;
}
if ($phone == "" || is_null($phone)){
	if ($email == "" || is_null($email)){
			$verified = false;
}
}
if ($name == "" || is_null($name)||  $sentIP == "" || is_null($sentIP)  ){
	$verified = false;
}


//Sending the email
if ($verified){

//Building the email
$to = 'andy@websitetalkingheads.com';
$subject = "Contact Form on WebsiteTalkingHeads.com";


$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";



// More headers
$headers .= 'From: <'.$email.'>' . "\r\n";
	$email_message = "Contact Form on WebsiteTalkingHeads.com<br>";
	$email_message .= "Name:" .$name. "<br>";
	$email_message .= "Company: ".$company." <br>";
	$email_message .= "Email: ".$email."<br>";
	$email_message .= "Phone: ".$phone." <br>";
	//$email_message .= "Request For: ".$request."<br>";
	$email_message .= "Message: ".$message."<br>";
	$email_message .= "Sent From: ".$sentIP."<br>";




	mail($to,$subject,$email_message,$headers);
	$message_send = "Thank You for Submitting Form";	
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Website Talking Heads - Add an Online Video Spokesperson to Your Website, Virtual Spokesperson, Website Video Spokesperson, Web Spokesperson, Website Actor</title>
<link href="../css/contact.css" rel="stylesheet" type="text/css" />
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<meta name="keywords" content="online spokesperson, video spokesperson, website talking heads, website actor, website video, transparent flash, virtual spokesperson, spokesperson, video presenter, website presenter, website spokesperson, video salesperson">
<meta name="description" content="Online video spokesperson.  For only $199, add a virtual spokesperson to your website.  An online presenter can increase traffic conversion rates on your website.  Integrate flash video, website video, website actor and objects to create dynamic streaming video and easily add it your existing website.">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="30 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="english">
<meta name="verify-v1" content="YNESpqoAwK51PmBV7/PFKLG0agx7AQPKhXXcYAXGGF8=" />
<meta name="norton-safeweb-site-verification" content="iinbv24r-1ix20hgj5l94wz2rnn3aiwi0336hwysvvpiskquy6ijsh9wy12f3znbed-hz1ay8ppzhgqap-sicqtw6ui29d0wrfcpenudh1ml9xwjbej7u25xy9pnm6yr" />
<link href="../styles.css" rel="stylesheet" type="text/css" />
<?php include ('../includes/googlescripts.php'); ?> 
</head>
<body>
<div id="container">
    <?php include ('../includes/header.php'); ?>
    
    
    
    <div id="contactHeader">Thank you for Contacting  Us.</div>
    <div id = "contactMessage">Thank you for contacting us at WebsiteTalkingHeads<sup>&#174;</sup>. One of our Project Managers will be in touch with you within 2 business days. </div>
    <div id = "callUs">If you would like to talk to us immediately please call us at<span class="blueText"> 801-748-2281</span>.</div>
    <div class="contactInfo">
        <div class="valueNames">
            <ul>    
                <li>Name: <?=$name?></li>
                <li>Company: <?=$company?></li>
                <li>Email: <?=$email?></li>
                <li>Phone: <?=$phone?></li>
                <li>Message: <?=$message?></li>
                <li>Sent From: <?=$referersite?></li>
                <li>IP: <?=$sentIP?></li>
                <li>Verified: <?=$verified?></li>
            </ul>
        </div>
        
        
    </div>
    <div id="c"></div>
    
    <?php include ('../includes/footer.php'); ?>   
</div>

<?php include ('../includes/chatform.php'); ?>  
</body>
</html>