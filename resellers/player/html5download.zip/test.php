<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Website Talking Heads - Add an Online Video Spokesperson to Your Website, Virtual Spokesperson, Website Video Spokesperson, Web Spokesperson, Website Actor</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<meta name="keywords" content="online spokesperson, video spokesperson, website talking heads, website actor, website video, transparent flash, virtual spokesperson, spokesperson, video presenter, website presenter, website spokesperson, video salesperson">
<meta name="description" content="Online video spokesperson.  For only $199, add a virtual spokesperson to your website.  An online presenter can increase traffic conversion rates on your website.  Integrate flash video, website video, website actor and objects to create dynamic streaming video and easily add it your existing website.">
<META NAME="robots" CONTENT="index, follow">
<META NAME="revisit-after" CONTENT="30 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="english">
<script src="assets/changeVideo.js" type="text/javascript"></script>
<link href="assets/player.css" rel="stylesheet" type="text/css" />
</head>
<body>




           <div id="MyPlayer">
                        <video id="videoBox" width="540" height="360" "alt="Jed" >
                    	<source src="http://www.websitetalkingheads.com/videos/Jed.mp4" type="video/mp4">
                   			Your browser does not support the video tag.
                        </video> 
                        <div id="videoBoxText">Jed</div>
                        <div class="PlayerBar">
                        <div id="Volume"><a href="#" onClick="muteToggle()"><img src="assets/VolumeBtn.png" width="30" height="30" alt="Volume" id="muteBtn" /></a></div>
                        <div id="timeDisplay">0:00/0:00</div>
                        <div id="PlayPause">
                        	<a href="#" onClick="playToggle()"><img  id="PlayPauseBtn" src="assets/PlayBtn.png" width="30" height="30" alt="Play Pause Button" /></a>
                            </div>
                        <div id="restartHolder">
                        	 <a href="#" onClick="restartToggle()"><img  id="RestartBtn" src="assets/RestartBtn.png" width="30" height="30" alt="Restart Button" /></a>
                         </div>
                        <div id="playerClose">
                        <a href="#" onClick="closePlayer()" onmouseover="exitOver(this)" onmouseout="exitOff(this)"><img src="assets/ExitBtn.png" width="30" height="30" alt="Close Player" id="exitBtn" /></a></div>
                        </div>
                        
            </div>
         
			<?php include ('assets/flashbackup.php'); ?> 


</body>
</html>